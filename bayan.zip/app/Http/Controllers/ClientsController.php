<?php

namespace App\Http\Controllers;

use App\Models\Operation;
use App\Models\Tree3;
use App\Models\Tree4;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

class ClientsController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $user = auth()->user();
        $tree4s = Tree4::where('tree3_code', 1205)
                       ->where('status', 1);

        if ($user->roles_name == ['owner']) {
            $tree4s = $tree4s->get(); // عرض جميع البيانات
        } elseif ($user->roles_name == ['agent']) {
            $tree4s = $tree4s->where('user_id', $user->id)->get(); // عرض البيانات التي أضافها المستخدم فقط
        }

        $tree3s = Tree3::all();
        $id = 1;

        return view('clients.Clients', compact('tree3s', 'tree4s', 'id'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function search()
    {
        $tree4s = Tree4::where('tree3_code', 1205)->where('status', 1)->get();

        return view('clients.index', compact('tree4s'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        // Validate the form data
        $validated = $request->validate([
            'tree4_name' => 'required|unique:tree4s,tree4_name',
            'iden' => 'required|unique:tree4s,iden',
            'phone' => 'required',
            'type' => 'required',
            'email' => 'required|email|unique:tree4s,email',
        ], [
            'tree4_name.required' => 'اسم الحاج مطلوب.',
            'tree4_name.unique' => 'اسم الحاج مستخدم بالفعل.',
            'iden.required' => 'رقم الهوية مطلوب.',
            'iden.unique' => 'رقم الهوية مستخدم بالفعل.',
            'phone.required' => 'رقم الهاتف مطلوب.',
            'email.required' => 'البريد الإلكتروني مطلوب.',
            'email.email' => 'صيغة البريد الإلكتروني غير صحيحة.',
            'email.unique' => 'البريد الإلكتروني مستخدم بالفعل.',
            'type.required' => 'النوع مطلوب.',
        ]);

        try {
            // Begin transaction
            DB::beginTransaction();

            // Create a new Tree4 entry
            $tree4 = new Tree4();
            $tree4->tree4_name = $validated['tree4_name'];
            $tree4->tree3_code = 1205;
            $tree4->iden = $validated['iden'];
            $tree4->phone = $validated['phone'];
            $tree4->email = $validated['email'];
            $tree4->location = $request->location;
            $tree4->nationalty = $request->nationalty;
            $tree4->file = $request->file;
            $tree4->status = 1;
            $tree4->type = $request->type;
            $tree4->user_id = Auth::user()->id;

            // Generate tree4_code
            $check = Tree4::where('tree3_code', 1205)->orderBy('id', 'DESC')->first();
            if ($check) {
                $tree4->tree4_code = $check->tree4_code + 1;
            } else {
                $tree4->tree4_code = ($tree4->tree3_code * 100000) + 1;
            }
            $tree4->save();

            // Commit transaction
            DB::commit();

            Session()->flash('success', 'تمت إضافة الحاج بنجاح');

            return redirect()->route('Clients.index');
        } catch (\Exception $e) {
            // Rollback transaction if any exception occurs
            DB::rollback();

            // Handle the exception and return error message
            return back()->withErrors(['error' => 'حدث خطأ أثناء إضافة البيانات. يرجى المحاولة مرة أخرى.'])->withInput();
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show(Request $request)
    {
        $start = $request->start;
        $end = $request->end;
        $name = $request->tree4;
        $Madin = Operation::where('Madin', $request->tree4)->whereDate('date', '>=', $request->start)->whereDate('date', '<=', $request->end)->orderBy('id', 'DESC')->get();
        $Dain = Operation::where('Dain', $request->tree4)->whereDate('date', '>=', $request->start)->whereDate('date', '<=', $request->end)->orderBy('id', 'DESC')->get();

        $id = 1;

        return view('clients.show', compact(
            'Madin',
            'Dain',
            'start',
            'end',
            'name',
            'id'

        ));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request)
    {
        // Validate the form data
        $request->validate([
            'id' => 'required|exists:tree4s,id',
            'tree4_name' => 'required|unique:tree4s,tree4_name,'.$request->id,
            'iden' => 'required|unique:tree4s,iden,'.$request->id,
            'phone' => 'required',
            'type' => 'required',
            'email' => 'required|email|unique:tree4s,email,'.$request->id,
        ], [
            'id.required' => 'معرف الحاج مطلوب.',
            'id.exists' => 'الحاج المحدد غير موجود.',
            'tree4_name.required' => 'اسم الحاج مطلوب.',
            'tree4_name.unique' => 'اسم الحاج مستخدم بالفعل.',
            'iden.required' => 'رقم الهوية مطلوب.',
            'iden.unique' => 'رقم الهوية مستخدم بالفعل.',
            'phone.required' => 'رقم الهاتف مطلوب.',
            'email.required' => 'البريد الإلكتروني مطلوب.',
            'email.email' => 'صيغة البريد الإلكتروني غير صحيحة.',
            'email.unique' => 'البريد الإلكتروني مستخدم بالفعل.',
            'type.required' => 'النوع مطلوب.',
        ]);

        // Find the Tree4 entry
        $tree4 = Tree4::find($request->id);
        $tree4->tree4_name = $request->tree4_name;
        $tree4->iden = $request->iden;
        $tree4->phone = $request->phone;
        $tree4->email = $request->email;
        $tree4->location = $request->location;
        $tree4->nationalty = $request->nationalty;
        $tree4->file = $request->file; // Assuming file is optional or handled separately
        $tree4->type = $request->type;
        $tree4->user_id = Auth::user()->id;
        $tree4->save();

        Session()->flash('edit', 'تمت تحديث بيانات الحاج بنجاح');

        return redirect()->route('Clients.index');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(Request $request)
    {
        $id = $request->id;
        Tree4::find($id)->delete();
        session()->flash('delete');

        return redirect()->route('Clients.index');
    }
}