<?php return array (
  'contracts' => 'App\\Http\\Livewire\\Contracts',
  'initial' => 'App\\Http\\Livewire\\Initial',
  'pakage' => 'App\\Http\\Livewire\\Pakage',
  'sales' => 'App\\Http\\Livewire\\Sales',
  'select' => 'App\\Http\\Livewire\\Select',
  'transport' => 'App\\Http\\Livewire\\Transport',
);