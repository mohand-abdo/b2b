<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('contracts', function (Blueprint $table) {
            $table->id();
            $table->string('hajj_number'); // رقم الحاج
            $table->string('room_number'); // رقم الغرفة
            $table->string('bus_number'); // رقم الحافلة
            $table->decimal('amount', 10, 2); // المبلغ
            $table->decimal('tax', 5, 2); // الضريبة (%)
            $table->decimal('total_amount', 10, 2); // المبلغ شامل الضريبة
            $table->date('contract_date'); // تاريخ العقد
            $table->text('contract_terms')->nullable(); // شروط العقد
            $table->integer('tree4_id'); // تعديل النوع ليتطابق مع `tree4_code`
            $table->foreign('tree4_id')
                  ->references('tree4_code')
                  ->on('tree4s')
                  ->onDelete('cascade');
            $table->unsignedBigInteger('campaign_id');
            $table->foreign('campaign_id')
                  ->references('id')
                  ->on('campaigns')
                  ->onDelete('cascade'); // حملة الحج والعمرة
            $table->unsignedBigInteger('bank_and_safe'); // الحساب
            $table->unsignedBigInteger('user_id'); // المستخدم
            $table->string('attachment')->nullable(); // مرفق
            $table->foreign('user_id')->references('id')->on('users')->onDelete('cascade');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('contracts');
    }
};
